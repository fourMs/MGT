function s = getsampling(d)

s = d.sampling;