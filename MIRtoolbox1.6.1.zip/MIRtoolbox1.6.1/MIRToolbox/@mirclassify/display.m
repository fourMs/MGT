function display(c)

% CLASSIFY/DISPLAY display of classification

