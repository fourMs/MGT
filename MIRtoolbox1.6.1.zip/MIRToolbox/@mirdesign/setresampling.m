function d = setresampling(d,s)

d.resampling = s;