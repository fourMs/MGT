addpath('./matlabPyrTools');
addpath('./mocaptoolbox');
addpath('./MIRtoolbox1.6.1');