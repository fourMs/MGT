function mgwaveplot(varargin)
% function mgwaveplot(varargin)
% mgwaveplot plots the waveform of the audio,and spectrum, rms,envelop of the audio
% syntax: mgwaveplot(mg)

% input: 
% mg: musical gestures data structure containing the audio information

% output:
% a figure showing the waveform,spectrum,rms,envelop of the audio

if isempty(varargin)
    return
end
audio = varargin{1}.audio.mir
ax1 = gca;
rms = mirrms(audio,'frame',2/varargin{1}.video.obj.FrameRate)
ax2 = gca;
spec = mirspectrum(audio)
ax3 = gca;
spec_rms = mirspectrum(rms)
ax4 = gca;
h = figure;
ax1_copy = copyobj(ax1,h);
ax2_copy = copyobj(ax2,h);
ax3_copy = copyobj(ax3,h);
ax4_copy = copyobj(ax4,h);
subplot(2,2,1,ax1_copy);
subplot(2,2,2,ax3_copy);
subplot(2,2,3,ax2_copy); 
subplot(2,2,4,ax4_copy);
figureobj = findobj('Type','figure');
l = length(figureobj);
close(figure(l-1))
close(figure(l-2))
close(figure(l-3))
close(figure(l-4))