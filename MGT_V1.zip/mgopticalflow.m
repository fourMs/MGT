function [flow,qom,com] = mgopticalflow(im,thres,value)
% function [flow,qom,com] = mgopticalflow(im,thres,value)
% mgopticalflow estimates the motion using the optical flow field
% syntax:[flow,qom,com] = mgopticalflow(im,thres,value)

% input:
% im: input image
% thres: 'Thres' indicates the threshold of the noise removal
% value: the value of threshold,(0,1)

% output:
% flow: optical flow field containing two components,horizontal and
% vertical direction
% qom: quantity of motion
% com: centroid of motion

% also see:opticalFlowLK, estimateFlow

if size(im,3)==3
    im = rgb2gray(im);
end
if nargin == 1
    opticalflow = opticalFlowHS;
    flow = estimateFlow(opticalflow,im);
end
if nargin == 3
    if strcmp(thres,'Thres')
        opticalflow = opticalFlowLK('NoiseThreshold',value);
        flow = estimateFlow(opticalflow,im);
    end
end
qom = sum(sum(flow.Magnitude));
[m,n] = size(flow.Magnitude);
x = 1:n;
y = 1:m;
meanx = mean(flow.Magnitude);
comx = x*meanx'/sum(meanx);
meany = mean(flow.Magnitude,2);
comy = y*meany/sum(meany);
com = [comx,comy];



